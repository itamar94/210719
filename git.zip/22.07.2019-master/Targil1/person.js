function Person(name, age, password,gender,car,bike)
{
    this.name = name
    this.age = age
    this.password = password
	this.gender=gender
	this.car=car
	this.bike=bike
	this.toString=function(){
		const {name, age, password,gender,car,bike}=this
		console.log(`name: ${name}, age: ${age}, password: ${password}, gender: ${gender}, car: ${car}, bike: ${bike}`)
	}
}
/*function Person({name, age, password,gender,car,bike})
{
    this.name = name
    this.age = age
    this.password = password
	this.gender=gender
	this.car=car
	this.bike=bike
}*/

class PersonC{
	constructor(name, age, password,gender,car,bike) {
    this.name = name
    this.age = age
    this.password = password
	this.gender=gender
	this.car=car
	this.bike=bike
  }
  set name(name){
	this.name = name
  }
  get name(){
	  return name;
  }
  toString(){
		const {name, age, password,gender,car,bike}=this
		console.log(`name: ${name}, age: ${age}, password: ${password}, gender: ${gender}, car: ${car}, bike: ${bike}`)
	}
/*  constructor({name, age, password,gender,car,bike}) {
    this.name = name
    this.age = age
    this.password = password
	this.gender=gender
	this.car=car
	this.bike=bike
  }*/
}