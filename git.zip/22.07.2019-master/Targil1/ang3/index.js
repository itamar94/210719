module.controller("formCtrl", FormCtrl)

function FormCtrl($scope) {
    $scope.person = new Person('')
    $scope.name = '';
}

class Person
{
    constructor(name)
    {
        this.name = name
    }
}