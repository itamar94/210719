function shuffle(a) {
    let j, x, i
    for (i = a.length - 1; i > 0; i--) {
        j = Math.floor(Math.random() * (i + 1));
        x = a[i];
        a[i] = a[j];
        a[j] = x;
    }
    return a;
}
module.value("data",{wrapper:{g:0,c:0}})
module.controller("parentCtrl",function ($scope,data){
	$scope.data=data
	const rand=[Math.floor(Math.random()*10),Math.floor(Math.random()*10),Math.floor(Math.random()*10),Math.floor(Math.random()*10)]
	const order=shuffle(rand.concat(rand))
	console.log(order)
	const xx=function(){
		$scope.n1="X"
		$scope.n2="X"
		$scope.n3="X"
		$scope.n4="X"
		$scope.n5="X"
		$scope.n6="X"
		$scope.n7="X"
		$scope.n8="X"
	}
	xx()
	var saved=null
	var over=0
	const howMany=function (){
		let i=0;
		if($scope.n1!=="X")i++;
		if($scope.n2!=="X")i++;
		if($scope.n3!=="X")i++;
		if($scope.n4!=="X")i++;
		if($scope.n5!=="X")i++;
		if($scope.n6!=="X")i++;
		if($scope.n7!=="X")i++;
		if($scope.n8!=="X")i++;
		return i
	}
	$scope.Uncover=function(id){
		if(howMany()<2){
			switch(id){
				case 1:
					$scope.n1=order[0]
					break;
				case 2:
					$scope.n2=order[1]
					break;
				case 3:
					$scope.n3=order[2]
					break;
				case 4:
					$scope.n4=order[3]
					break;
				case 5:
					$scope.n5=order[4]
					break;
				case 6:
					$scope.n6=order[5]
					break;
				case 7:
					$scope.n7=order[6]
					break;
				case 8:
					$scope.n8=order[7]
					break;
			}
			if(saved===null)saved=id;
			else{
				if(order[saved-1]===order[id-1]){
					$scope.data.wrapper={g:$scope.data.wrapper.g+1,c:$scope.data.wrapper.c+1}
					document.getElementById(id).style.display="none"
					document.getElementById(saved).style.display="none"
					saved=null
					xx()
					if((++over)===4)alert("Game Over");
				}
			}
		}
		else alert("click on Reset")
	}
	$scope.Reset=function(){
		if(howMany()>=2){
			saved=null
			xx();
			$scope.data.wrapper.g++;
		}
	}
})

module.controller("scoreCtrl",function ($scope,data){
	$scope.data=data
})
