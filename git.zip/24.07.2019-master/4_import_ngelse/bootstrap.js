// bootstrap the application
const module = angular.module("dataApp", ['elif'])