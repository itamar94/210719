function shuffle(a) {
    let j, x, i
    for (i = a.length - 1; i > 0; i--) {
        j = Math.floor(Math.random() * (i + 1));
        x = a[i];
        a[i] = a[j];
        a[j] = x;
    }
    return a;
}
module.value("data",{wrapper:{g:0,c:0}})
module.value("data2",{wrapper:{g:0,c:0}})
module.controller("parentCtrl",function ($scope,data,data2){
	$scope.Pn=1
	$scope.data=data
	$scope.data2=data
	const rand=[]
	let size=24//the Size of the board
	for(let i=0;i<(size/2);i++)
		rand.push(Math.floor(Math.random()*10));
	const order=shuffle(rand.concat(rand))
	$scope.cards=[]
	for(let i=0;i<size;i++){
		$scope.cards.push({})
		$scope.cards[i].id=i
		$scope.cards[i].value="X"
		$scope.cards[i].f=function(){
		$scope.Uncover(i)
		}
	}
	console.log($scope.cards)
	const xx=function(){
		for(let i=0;i<size;i++)
			$scope.cards[i].value="X";
	}
	var saved=null
	var over=0
	const howMany=function (){
		let count=0
		for(let i=0;i<size;i++)
			if($scope.cards[i].value!=="X")count++;
		return count
	}
	$scope.Uncover=function(id){
		if(howMany()<2){
			$scope.cards[id].value=order[id]
			if(saved===null)saved=id;
			else{
				if(order[saved]===order[id]){
					if($scope.Pn==1)$scope.data.wrapper={g:$scope.data.wrapper.g+1,c:$scope.data.wrapper.c+1};
					else $scope.data2.wrapper={g:$scope.data2.wrapper.g+1,c:$scope.data2.wrapper.c+1};
					document.getElementById(id).style.opacity=0
					document.getElementById(saved).style.opacity=0
					saved=null
					xx()
					if((++over)===size/2)alert("Game Over");
				}
			}
		}
		else $scope.Pn=$scope.Pn==1?2:1;
	}
	$scope.Reset=function(){
		if(howMany()>=2){
			saved=null
			xx();
			if($scope.Pn==1)$scope.data.wrapper.g++;
			else $scope.data2.wrapper.g++;
			$scope.Pn=$scope.Pn==1?2:1;
		}
	}
})

module.controller("scoreCtrl",function ($scope,data){
	$scope.data=data
})
module.controller("score2Ctrl",function ($scope,data2){
	$scope.data=data2
})
