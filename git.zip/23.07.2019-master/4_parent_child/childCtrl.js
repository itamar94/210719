
module.controller("childCtrl", ChildCtrl)


// DI dependency injection - IOC
function ChildCtrl($scope) {

    $scope.y = 1
//    $scope.$parent
    //$scope.x = 12
    this.x = 5


}

module.controller("equals", equalsCtrl)
// DI dependency injection - IOC
function equalsCtrl($scope,$rootScope) {
	$scope.r = $rootScope
	$scope.printValue=function(){
		switch($scope.$parent.func){
			case "+":
				$scope.x=$scope.$parent.num1+$scope.$parent.num2;
				break;
			case "-":
				$scope.x=$scope.$parent.num1-$scope.$parent.num2;
				break;
			case "*":
				$scope.x=$scope.$parent.num1*$scope.$parent.num2;
				break;
			case "/":
				$scope.x=$scope.$parent.num1/$scope.$parent.num2;
				break;
		}
    };
	$scope.printValueRoot=function(){
		alert($scope.r.num1r)
		alert($rootScope.num1r)
		alert($rootScope.funcr)
		switch($rootScope.funcr){
			case "+":
				$scope.x=$rootScope.num1r+$rootScope.num2r;
				break;
			case "-":
				$scope.x=$rootScope.num1r-$rootScope.num2r;
				break;
			case "*":
				$scope.x=$rootScope.num1r*$rootScope.num2r;
				break;
			case "/":
				$scope.x=$rootScope.num1r/$rootScope.num2r;
				break;
		}
    };
}

