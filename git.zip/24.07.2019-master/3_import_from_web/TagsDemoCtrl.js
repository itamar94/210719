appModule.controller("TagsDemoCtrl", TagsDemoCtrl);

function TagsDemoCtrl() {
    this.tags = [
    { text: 'hello' },
    { text: 'angular' },
    { text: 'js' }
  ];
}