
module.controller("parentCtrl", ParentCtrl)

// DI dependency injection - IOC
function ParentCtrl($scope, $rootScope, globalConst, dataService, apiService) {
    $scope.productName = globalConst.name
    $scope.productVersion = globalConst.ver
    
    $scope.items = [1,2,3,4,5]

    //$scope.data = dataService
    dataService.items = $scope.items

    $scope.calcPower = function() {
        alert( `3 ^ 2 = ${apiService.getPower2(3)}`)
    }
    $scope.api = apiService
}

module.controller("EnterCtrl", function($scope,ABService) {
   $scope.ab = ABService
})
module.controller("sumCtrl",function ($scope,ABService,savedTerms) {
	$scope.ab = ABService
	$scope.colors=savedTerms
})
module.controller("divCtrl",function ($scope,ABService,savedTerms) {
	$scope.ab = ABService
	$scope.errC=savedTerms
	$scope.err=$scope.errC.err;
})
module.controller("printACtrl",function ($scope,ABService,PrintA) {
	$scope.print=function(){
		$scope.items=PrintA.get1toA().nums
		//console.log($scope.items.length)
	}
})
module.controller("printBCtrl",function ($scope,ABService,PrintB) {
	$scope.print=function(){
		PrintB.getBto1()
		$scope.items=PrintB.items
		console.log($scope.items.length)
	}
})