module.constant("globalConst", {
    name : '3D Graphics',
    ver : 5.8
})

module.constant("savedTerms", {
    err : 'wrong',
    g1:{pos: 'red',neg: 'blue'},
    g2:{pos: 'green',neg: 'yellow'}
})