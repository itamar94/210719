module.value("dataService", {
    items : [],
    sayHello : function() { alert('hello')}
})

module.value("ABService",{numbers:{a:0,b:0},colors:'g1',err:'wrong'})