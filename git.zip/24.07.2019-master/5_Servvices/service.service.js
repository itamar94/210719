module.service("serviceService", function(apiService, globalConst) {
    
    this.myname = 'cool service!'

    this.getUpper = function(s) { 
        return s.toUpperCase()
    }
})

module.service("PrintB", function(ABService) {
	this.items=[]
	this.getBto1=function(){
		this.items=[]
		if(ABService.numbers.b>0)this.items.push(ABService.err);
		for(let i=ABService.numbers.b;i<0;i++)this.items.push(i);
	}
})