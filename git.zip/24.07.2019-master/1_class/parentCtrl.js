
module.controller("parentCtrl", ParentCtrl)

// DI dependency injection - IOC
function ParentCtrl($scope, $rootScope) {
	$scope.name='';
	$scope.age='';
	$scope.email='';
	
	$scope.color=function(){
		if(($scope.name==='')&&($scope.email==='')&&($scope.age===''))
			return 'missing';
		else if(($scope.name!=='')&&($scope.email!=='')&&($scope.age!=='')){
			if(parseInt($scope.age)<18)return 'eigh';
			return 'ok';
		}
		else return 'almost';
	}
}
