function clicked()
{
    //alert(document.getElementById("nameTxt").value)
    //call new Person with values from input boxes
    //-- create Person
    //console.log(person)
    // -- use class
	let name=document.getElementById("nameTxt").value
	let age=document.getElementById("ageTxt").value
	let password=document.getElementById("passTxt").value
	let gender="other"
	if(document.getElementById("male").checked)
		gender="male";
	else if(document.getElementById("female").checked)
		gender="female";
	let car=document.getElementById("car").value
	let bike=document.getElementById("bike").value
	const p1=new Person(name, age, password,gender,car,bike)
	console.log(p1)
	const p2=new PersonC(name, age, password,gender,car,bike)
	console.log(p1)
}