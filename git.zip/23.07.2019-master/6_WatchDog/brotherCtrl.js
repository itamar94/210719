module.controller("brotherCtrl", BrotherCtrl)


// DI dependency injection - IOC
function BrotherCtrl($scope, $rootScope) {

    /*
    first solution for auto run of code whenever x is modified
    $scope.everyTime = function() {
        alert("called me....")
        return 10
    }
    */
}
module.controller("NameZone", NameZonef)
// DI dependency injection - IOC
function NameZonef($scope) {
	$scope.$watch('x',function(n) {
        if(n==="Slim Shady")alert("Thats my name");
    })
}
