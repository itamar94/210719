module.constant("url",{url:"https://jsonplaceholder.typicode.com/posts"})
module.value("data",{wrapper:{allData:[],dataId:{}}})
module.service("req",function($http,url,data){
	this.wrapper={}
	data.wrapper=this.wrapper
    let p=$http.get(url.url)
    p.then( (resp) => {
        this.wrapper.allData=resp.data
		console.log(data)
    },(err) => {
        console.log(`ERROR === ${err}`)   
    })
	this.getDataById=function(id){
		let p=$http.get(url.url+"/"+id)
		p.then((resp) => {
        this.wrapper.dataId=resp.data
		console.log(data.wrapper.dataId)
    },(err) => {
        console.log(`ERROR === ${err}`)   
    })
	}
})

module.controller("parentCtrl", ParentCtrl)
function ParentCtrl($scope,req,data){
	$scope.id=1	
	$scope.todos=data
	//$scope.$watch('id',function(){const id=$scope.id;req.getDataById(id);})
		$scope.make=function(){
			req.getDataById($scope.id);
		}
}
