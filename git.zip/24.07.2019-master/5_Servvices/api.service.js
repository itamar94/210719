module.factory("apiService", function(globalConst) {
    const result = {}

    result.specialItems = ['a','b','c']

    result.getPower2 = function (x) {
        return x * x
    }

    return result
})

module.factory("PrintA", function(ABService) {
    let result = {nums:[]}
	result.get1toA=function(){
		result = {nums:[]}
		if(ABService.numbers.a<0)return result['nums'].push(ABService.err);
		for(let i=0;i<ABService.numbers.a;i++)result['nums'].push(i);
	return result
	}
    
    return result
})