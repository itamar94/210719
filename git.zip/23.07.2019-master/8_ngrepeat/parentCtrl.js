module.controller("parentCtrl", ParentCtrl)
//let value1 

// DI dependency injection - IOC
function ParentCtrl($scope, $rootScope) {

    $rootScope.devices = [
        new Mobile({model: "IPhone X", color: "black", price: 3500}),
        new Mobile({model: "Xiaomi", color: "green", price: 1000}),
        new Mobile({model: "Samsung Galaxy 11+", color: "black", price: 5500}),
        new Mobile({model: "LG V60", color: "White", price: 7500})
    ]
	$scope.remove=function(n){
		$rootScope.devices.splice(n,1)
	}
    $scope.add=function(){
		$rootScope.devices.push(new Mobile({model: $scope.mod, color: $scope.col, price: $scope.pri}))
	}
	$scope.update=function(id){
		if(id<$rootScope.devices.length)
		$rootScope.devices[id]=new Mobile({model: $scope.mod, color: $scope.col, price: $scope.pri})
	}
	$scope.edit=function(id){
		$scope.mod=$rootScope.devices[id].model
		$scope.col=$rootScope.devices[id].color
		$scope.pri=$rootScope.devices[id].price
		$scope.id=id
	}
	$scope.order=function(what){
		if($scope.what===what)
			$scope.what="-"+what
		else
		$scope.what=what;
	}
	$scope.filt={}
	$scope.$watch('Sm',function(){
		$scope.filt["model"]=$scope.Sm
	})
	$scope.$watch('Sc',function(){
		$scope.filt["color"]=$scope.Sc
	})
	$scope.$watch('Sp',function(){
		$scope.filt["price"]=$scope.Sp
	})
}
