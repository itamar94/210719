const secondModule = angular.module("mysecondmodule", [])

secondModule.controller("HelloController", HelloCtrl);

function HelloCtrl() {
    this.message = "Hello I am hello controller in second module"
}

const thi = angular.module("third", [])

thi.controller("thirdc", thirdCtrl);

function thirdCtrl($scope) {
    $scope.message = "Hello I am hello controller in third module"
}

