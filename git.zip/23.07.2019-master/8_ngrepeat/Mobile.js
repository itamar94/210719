class Mobile {
    constructor({model, color, price}) {
        this.model = model
        this.color = color
        this.price = price
    }
}